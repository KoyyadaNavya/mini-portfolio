# Mini Portfolio

This is a simple personal portfolio webpage that includes:

- A short bio with your name and image
- A list of your skills
- Two sample projects
- A contact form
- JavaScript-based form alert interaction

## Live Demo

[Your Live Link Here](https://yourusername.github.io/mini-portfolio)

## How to Use

1. Clone the repo or download the ZIP
2. Open `index.html` in a browser
3. Replace images and text with your content
4. Deploy on GitHub Pages or Netlify
